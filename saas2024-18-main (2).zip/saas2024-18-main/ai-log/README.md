# ai-log

Περιεχόμενα:

- Όλα τα αρχεία του ai-tools-questionnaire - SaaS 24A που ανεβάσατε είτε με το frontend https://ailog.softlab.ntua.gr/ είτε με το CLI tool, το οποίο μπορείτε να κατεβάσετε απο το front-end.

  
**Προσοχή 1:** προσπαθείστε τα ονόματα αρχείων να διευκολύνουν την ταξινόμηση πχ 2023-10-29-16:55-req.zip
  
**Προσοχή 2:** κάθε αρχείο zip περιέχει:
- το αρχείο μεταδεδομένων
- το σύνολο του διαλόγου (prompts & answers) με το εργαλείο
  
Δείτε το video: https://youtu.be/eUAjxCRNODU