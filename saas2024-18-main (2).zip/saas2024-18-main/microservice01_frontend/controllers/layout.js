const jwt_decode = require('jwt-decode');
const axios = require('axios');

exports.landing = (req, res, next) => {

    let isOK = true;
    res.render('landing.ejs', {
        pageTitle: "Welcome Page",
        serviceUp: isOK,
        messages: [],
        base_url: process.env.BASE_URL,
    })
}

exports.profile = function(req, res, next) {
    
    let totalProblems, totalSolutions, isOK_Analytics = true, daysRegistered;
    
    req.session.messages = [];
    const userData = jwt_decode(req.session.user.jwtToken);

    /* Construct the url of analytics service (user statistics) */
    const url_analytics = `http://${process.env.BASE_URL}:4003/analytics`;

    const headers = { 
        'X-OBSERVATORY-AUTH': req.session.user.jwtToken,
        "SERVICES-HEADER": process.env.SECRET_SERVICES
    };

    /* Create the configs for the requests */
    const config_analytics = { method: 'get', url: url_analytics, headers: headers};

    /* Request to get User statistics */
    let analyticsPromise = new Promise((resolve, reject) => {
        axios(config_analytics)
        .then(result => {
            totalProblems = result.data.totalProblems; 
            totalSolutions = result.data.totalSolutions;
            solved_per_day = result.data.solved_per_day;
            daysRegistered = result.data.daysRegistered;
            resolve(); 
        })
        .catch(err => { isOK_Analytics = false; resolve(); });
    })
    
    /* After all data is retrieved render the page */
    Promise.all([analyticsPromise]).then(() => {

        let messages = req.flash("messages");
        if (messages.length == 0) messages = [];

        res.render('problemsPerday.ejs', {
            pageTitle: "My Analytics",
            totalProblems: isOK_Analytics ? totalProblems : 0,
            totalSolutions: isOK_Analytics ? totalSolutions : 0,
            solved_per_day: isOK_Analytics ? solved_per_day : 0,
            serviceUpAnalytics: isOK_Analytics,
            currentCredits: userData.user.credits,
            newbalance: req.session.user.newbalance,
            daysRegistered: daysRegistered,
            messages: messages,
            base_url: process.env.BASE_URL
        });
    })

}

exports.home = (req, res, next) => {
    let isOK = true;
    req.session.messages = [];
    const userData = jwt_decode(req.session.user.jwtToken);

    res.render('home.ejs', {
        pageTitle: "Home Page",
        currentCredits: userData.user.credits,
        newbalance: req.session.user.newbalance,
        serviceUp: isOK,
        messages: [],
        base_url: process.env.BASE_URL,
    })
};