const jwt_decode = require('jwt-decode');
const axios = require('axios');

exports.submitProblem = (req, res, next) => {
    let isOK = true;
    solver = req.session.solver;

    const userData = jwt_decode(req.session.user.jwtToken);
    const metadataFields = req.session.solver.metadata; // Assuming metadata fields are stored in session

    // Construct the metadata object from the request body
    let metadata = {};
    metadataFields.forEach(field => {
        metadata[field] = req.body[field];
    });
    console.log("Metadata:", metadata);
    const url = `http://${process.env.BASE_URL}:4004/problem`;
    const data = {
        metadata: metadata,
        solverId: solver.id,
        usersId: userData.user.id
    };

    const headers = { 
        'X-OBSERVATORY-AUTH': req.session.user.jwtToken,
        "SERVICES-HEADER": process.env.SECRET_SERVICES
    };

    const config = { method: 'post', url: url, headers: headers, data: data };
    
    axios(config)
    .then(result => {
        req.flash('messages', { type: result.data.type, value: result.data.message });
        if (result.data.message === 'Problem submitted successfully!' && result.data.type === 'success') {
            req.session.authenticated = true;
            return res.render('browseProblems.ejs', {
                pageTitle: "All Submissions",
                currentCredits: userData.user.credits,
                newbalance: req.session.user.newbalance,
                serviceUp: isOK,
                messages: req.session.messages,
                base_url: process.env.BASE_URL,
                submissions: result.data.submissions,
            });
        } else {
            return res.render('solveProblem.ejs', {
                pageTitle: req.session.solver.name,
                currentCredits: userData.user.credits,
                newbalance: req.session.user.newbalance,
                serviceUp: isOK,
                messages: req.session.messages,
                base_url: process.env.BASE_URL,
                metadata: req.session.solver.metadata,
                input: req.session.solver.input
            });
        }
    })
    .catch(err => {
        console.error('API Error:', err); // Improved logging
        if (err.response) {
            console.error('API Error Response:', err.response.data); // Improved logging
            req.flash('messages', { type: err.response.data.type, value: err.response.data.message });
        } else {
            req.flash('messages', { type: 'error', value: 'An unexpected error occurred.' });
        }
        return res.render('solveProblem.ejs', {
            pageTitle: req.session.solver.name,
            currentCredits: userData.user.credits,
            newbalance: req.session.user.newbalance,
            serviceUp: isOK,
            messages: req.session.messages,
            base_url: process.env.BASE_URL,
            metadata: req.session.solver.metadata,
            input: req.session.solver.input
        });
    });
};


exports.browseProblems = (req, res, next) => {
    let action = req.body.action;
    let submission_id = req.body.id;
    isOK=true;

    const userData = jwt_decode(req.session.user.jwtToken);
    
    const headers = { 
        'X-OBSERVATORY-AUTH': req.session.user.jwtToken,
        "SERVICES-HEADER": process.env.SECRET_SERVICES
    };
    let config;

    if(action=="run"){
        const url = `http://${process.env.BASE_URL}:4004/solution`;
        const data = {
            action: action,
            submission_id: submission_id,
        };
        config = { method: 'post', url: url, headers: headers, data: data };

    } else if (action=="results" || action=="view"){
        const url = `http://${process.env.BASE_URL}:4004/solution`;
        const data = {
            action: action,
            submission_id: submission_id,
        };
        config = { method: 'post', url: url, headers: headers, data: data };
    } else if (action=="delete"){
        const url = `http://${process.env.BASE_URL}:4004/problems`;
        const data = {
            action: action,
            submission_id: submission_id,
        };
        config = { method: 'post', url: url, headers: headers, data: data };
    } else {
        const url = `http://${process.env.BASE_URL}:4004/problems`;
        config = { method: 'post', url: url, headers: headers };
    }

    axios(config)
    .then(result => {
        if (result.data.message === 'All Problems!' && result.data.type === 'success') {
            req.session.authenticated = true;

            res.render('browseProblems.ejs', {
                pageTitle: "All Submissions",
                currentCredits: userData.user.credits,
                newbalance: req.session.user.newbalance,
                serviceUp: isOK,
                messages: req.session.messages,
                base_url: process.env.BASE_URL,
                submissions: result.data.submissions
            });
        } else if (result.data.message === 'Solution submitted successfully!' && result.data.type === 'success') {
                req.session.authenticatxsed = true;
                console.log("The solution is: ", result.data.solution.data);
                res.render('Solutions.ejs', {
                    pageTitle: "Solutions",
                    currentCredits: userData.user.credits,
                    newbalance: req.session.user.newbalance,
                    serviceUp: isOK,
                    messages: req.session.messages,
                    base_url: process.env.BASE_URL,
                    solution: result.data.solution.data,
                    problem: result.data.problem,
                });
        } else {
            return res.redirect("/home");
        }
    })
    .catch(err => {
        console.error('API Error:', err); // Improved logging
        if (err.response) {
            console.error('API Error Response:', err.response.data); // Improved logging
            req.flash('messages', { type: err.response.data.type, value: err.response.data.message });
        } else {
            req.flash('messages', { type: 'error', value: 'An unexpected error occurred.' });
        }
        return res.redirect("/home");

    });
};

exports.solver = (req, res, next) => {
    let isOK = true;
    let solverId = req.body.id;

    console.log("Solver ID: ", solverId);
    const userData = jwt_decode(req.session.user.jwtToken);

    const url = `http://${process.env.BASE_URL}:4005/solver`;
    const data = {
        solverId: solverId,
    };

    const headers = { 
        'X-OBSERVATORY-AUTH': req.session.user.jwtToken,
        "SERVICES-HEADER": process.env.SECRET_SERVICES
    };

    const config = { method: 'get', url: url, headers: headers, data: data };
    
    axios(config)
    .then(result => {
        console.log("Result", result);
        console.log("Result data", result.dataß);
        req.flash('messages', { type: result.data.type, value: result.data.message });
        if (result.data.message === 'Solver found successfully!' && result.data.type === 'success') {
            req.session.authenticated = true;
            req.session.solver = result.data.solver; 
            return res.render('solveProblem.ejs', {
                pageTitle: result.data.solver.name,
                currentCredits: userData.user.credits,
                newbalance: req.session.user.newbalance,
                serviceUp: isOK,
                messages: req.session.messages,
                base_url: process.env.BASE_URL,
                metadata: result.data.solver.metadata,
                input: result.data.solver.input
            });
        }
    })
    .catch(err => {
        console.error('API Error:', err); // Improved logging
        if (err.response) {
            console.error('API Error Response:', err.response.data); // Improved logging
            req.flash('messages', { type: err.response.data.type, value: err.response.data.message });
        } else {
            req.flash('messages', { type: 'error', value: 'An unexpected error occurred.' });
        }
        return res.redirect('/home');
    });
};

