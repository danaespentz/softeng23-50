const axios = require('axios');
const jwt_decode = require('jwt-decode');

exports.signIn = (req, res, next) => {
    const email = req.body.email;
    const password = req.body.password;

    const url = `http://${process.env.BASE_URL}:4002/signin`;
    const data = {
        email: email,
        password: password
    };
    const headers = { "SERVICES-HEADER": process.env.SECRET_SERVICES };
    const config = { method: 'post', url: url, headers: headers, data: data };

    axios(config)
    .then(result => {
        req.flash('messages', { type: result.data.type, value: result.data.message })
        if (result.data.message === 'Welcome back!' && result.data.type === 'success') {
            
            req.session.authenticated = true;
            req.session.user = {
                jwtToken: result.data.token 
            };

            return res.redirect('/home');
        }
        else return res.redirect('/');

    })
    .catch(err => {
        req.flash('messages', { type: err.response.data.type, value: err.response.data.message })
        return res.redirect('/');

    });
}

exports.credits = (req, res, next) => {
    const new_credits = req.body.new_credits;
    const userData = jwt_decode(req.session.user.jwtToken);
    const url = `http://${process.env.BASE_URL}:4002/credits`;
    const data = {
        new_credits: new_credits,
        id: userData.user.id
    };
    const headers = { "SERVICES-HEADER": process.env.SECRET_SERVICES };
    const config = { method: 'post', url: url, headers: headers, data: data };

    axios(config)
    .then(result => {
        req.flash('messages', { type: result.data.type, value: result.data.message })
        if (result.data.message === 'New Credits!' && result.data.type === 'success') {
            
            req.session.authenticated = true;
            req.session.user = {
                newbalance: result.data.balance,
                jwtToken: req.session.user.jwtToken,
                currentCredits: result.data.balance
            };
            
            return res.redirect('/home');
        }
        else return res.redirect('/home');

    })
    .catch(err => {
        req.flash('messages', { type: err.response.data.type, value: err.response.data.message })
        return res.redirect('/home');

    });
}

exports.signUp = (req, res, next) => {
    const name = req.body.name;
    const email = req.body.email;
    const password = req.body.password;

    const url = `http://${process.env.BASE_URL}:4002/signup`;
    const data = {
        name: name,
        email: email,
        password: password,
    };
    const headers = { "SERVICES-HEADER": process.env.SECRET_SERVICES };
    const config = { method: 'post', url: url, headers: headers, data: data };

    axios(config)
    .then(result => { 
        req.flash('messages', { type: result.data.type, value: result.data.message })
        return res.redirect('/');

    })
    .catch(err => {
        req.flash('messages', { type: err.response.data.type, value: err.response.data.message })
        return res.redirect('/');

    });
};

exports.signOut = (req, res) => {
        req.session.destroy(err => {
        res.redirect('/');
    });
}
