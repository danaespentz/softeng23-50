const express = require('express');
const auth = require('../middlewares/authentication');
const problem = require('../controllers/problem');
const router = express.Router();

router.post('/submit', auth, problem.submitProblem);

router.post('/solver', auth, problem.solver);

router.post('/browse', auth, problem.browseProblems);

module.exports = router;