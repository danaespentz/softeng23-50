const express = require('express');
const auth = require('../middlewares/authentication');
const layout = require('../controllers/layout');

const router = express.Router();

router.get('/', layout.landing);

router.get('/profile', auth, layout.profile);

router.get('/home', auth, layout.home);

module.exports = router;