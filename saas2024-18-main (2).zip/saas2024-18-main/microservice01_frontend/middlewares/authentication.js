const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    const token = req.session.user.jwtToken;
    
    // If not authenticated, redirect to home
    if (!req.session.authenticated) {
        req.flash('messages', {type: 'error', value: 'Please log in to access this page.'});
        return res.redirect('/');
    }

    if (token) {
        let decoded;
        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET);
        } catch (err) {
            req.flash('messages', {type: 'error', value: 'Your session has expired.'});
            req.session.authenticated = false;
            return res.redirect('/');
        }
        
        // If token is invalid or expired, redirect to home
        if (!decoded) {
            req.flash('messages', {type: 'info', value: 'Not authenticated.'});
            req.session.authenticated = false;
            return res.redirect('/');
        }

        // If token is valid, set user object and proceed
        req.user = decoded.user;
        next();
    } else {
        req.flash('messages', {type: 'error', value: 'Authentication token missing.'});
        req.session.authenticated = false;
        return res.redirect('/');
    }
}
