const Sequelize = require('sequelize');
module.exports = function(sequelize, DataTypes) {
  return sequelize.define('Sessions', {
    sid: {
      type: DataTypes.TEXT,
      allowNull: false,
      primaryKey: true
    },
    expire: {
      type: DataTypes.ARRAY(DataTypes.DATE),
      allowNull: true
    },
    data: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    Sequelize,
    tableName: 'Sessions',
    schema: process.env.DB_SCHEMA,
    timestamps: false,
    indexes: [
      {
        name: "Sessions_pkey",
        unique: true,
        fields: [
          { name: "sid" },
        ]
      },
    ]
  });
};
