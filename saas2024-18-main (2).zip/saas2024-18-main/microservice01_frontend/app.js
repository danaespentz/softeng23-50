const express = require('express');
const path = require('path');
const session = require('express-session');
const sequelize = require('./utils/database');
var initModels = require("./models/init-models");
const SequelizeStore = require('connect-session-sequelize')(session.Store);
const flash = require('connect-flash')

const layout = require('./routes/layout');
const account = require('./routes/account');
const problem = require('./routes/problem');

const app = express();

initModels(sequelize);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(flash());

app.use(session({
    secret: process.env.SECRET,
    resave: false,
    saveUninitialized: false,
    store: new SequelizeStore({
        db: sequelize,
        table: 'Sessions',
    }),
}));

app.use((req, res, next) => {
    console.log(req.session.user);
    res.locals.authenticated = req.session.authenticated;
    res.locals.user = req.session.user;
    next();
});

app.use('/', layout);
app.use('/account', account);
app.use('/problems', problem);

app.use((req, res, next) => { res.status(404).json({message: 'Endpoint not found!'}); })

module.exports = app;