const app = require("./app");
const sequelize = require("./utils/database");
const port = Number(4001);

sequelize
    .query(`CREATE SCHEMA IF NOT EXISTS "${process.env.DB_SCHEMA}";`)
    .then(() => {
        sequelize
            .sync({
                force: true,
            })
            .then((result) => {
                app.listen(port, () => {
                    console.log(`Server running on port ${port}!`);
                });
            })
            .catch((err) => console.log(err));
    })
    .catch((err) => console.log(err));