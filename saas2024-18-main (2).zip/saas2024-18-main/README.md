# NTUA ECE SAAS 2024 PROJECT
  
## TEAM 18

  
## Project Overview

SolveMyProblem is a sophisticated web-based platform that provides computational problem-solving services as a SaaS (Software as a Service) solution, developed as part of the Software as a Service course at ECE NTUA. It offers users access to powerful computational resources and specialized software licenses for solving complex challenges, including simulations, optimizations, and predictions, without the need for costly hardware and software investments. Leveraging Google OR-Tools, SolveMyProblem efficiently handles a variety of operations research tasks, such as optimization problems requiring extensive processing power. Users can submit their problems, which are then processed using the platform’s robust computational infrastructure. Built on a microservices architecture and deployed using Docker containers, SolveMyProblem ensures efficient, scalable, and seamless operations.

## Contributors

This project is the result of collaborative efforts by:

- [Nektarios Mpoumpalos](https://github.com/ntua-el20441)
- [Alexandros Papanastasiou](https://github.com/ntua-el17647) 
- [Danae Spentzou](https://github.com/ntua-el20237)


## Usage

### Running with Docker
1. **Clone the Repository:**
   ```bash
   git clone https://github.com/ntua/saas2024-18.git
   cd saas2024-18
   ```

2. **Docker Installation**
   Make sure you have Docker installed on your system. You can download it from [Docker's official website](https://www.docker.com/get-started).
   Start the Docker Engine from the Docker Desktop App.

4. **Run Docker Compose:**
   Navigate to the directory containing the solveMyProblem.yml file and run Docker Compose:
   ```bash
   docker-compose -f solveMyProblem.yml up -d --build
   ```
   This command will start all the services defined in the solveMyProblem.yml file. It will pull the necessary Docker images and start all the containers. If you already built the containers, then you can run the project with the following command:

   ```bash
   docker-compose -f solveMyProblem.yml up
   ```
   If changes are made to any of the microservices you will have to rebuild the project.


5. **Stopping the Services:**
   To stop the services, press Ctrl + C in the terminal where Docker Compose is running. You can also use:
   ```bash
   docker-compose -f solveMyProblem.yml down
   ```
   You may also need to stop the Docker Engine running in the background.

## Services

### Front-end Service
- Provides the user interface for the application.
- [Front-end Service README](https://github.com/ntua/saas2024-18/tree/main/microservice01_front-end/README.md)
- http://localhost:4001

### Accounts Service
- Manages user accounts, signup and login.
- [Accounts Service README](https://github.com/ntua/saas2024-18/tree/main/microservice02_accounts/README.md)
- http://localhost:4002

### Analytics Service
- Manages user analytics, including problems per day.
- [Analytics Service README](https://github.com/ntua/saas2024-18/tree/main/microservice03_analytics/README.md)
- http://localhost:4003

### Solutions Service
- Sends problems for execution to the appropriate solver. Handles creating, updating, and deleting user submissions. Stores and provides access to problem execution results.
- [Solutions Service README](https://github.com/ntua/saas2024-18/tree/main/microservice04_solutions/README.md)
- http://localhost:4004

### Solve Problems Service
- Finds the appropriate problem solver and returns its metadata.
- [Solve Problems Service README](https://github.com/ntua/saas2024-18/tree/main/microservice05_solve_problem/README.md)
- http://localhost:4005


## Diagrams

### Overview
---
Our project documentation features a variety of diagrams created using Visual Paradigm. These diagrams offer a comprehensive visual representation of the solveMyProblem system, helping to clarify its design, architecture, and functionality.

1. **UML Class/API Diagram**: Depicts the system's classes, including their attributes, methods, and interrelationships, providing insight into the API structure and object-oriented design.

2. **UML Sequence Diagram**: Shows the sequence of messages exchanged between different system objects or components during specific scenarios, highlighting the interaction and timing between elements.

3. **UML Deployment Diagram**: Visualizes the deployment of software on the hardware infrastructure, illustrating the physical setup of hardware nodes and their corresponding software.
   
4. **UML Component Diagram**: Displays the organization and dependencies among various software components, such as libraries, packages, and files.

These diagrams are located in the [architecture](https://github.com/ntua/saas2024-18/tree/main/architecture) folder within our project repository.


## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
