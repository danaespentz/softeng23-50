# Solutions Service

## Overview
The Solutions Service is responsible for haddling the problem submitions.

## Features
Sends problems for execution to the appropriate solver. 
Handles creating, updating, and deleting user submissions. 
Stores and provides access to problem execution results.

## API Endpoints
- `GET /healthcheck`: Check the health of the service.
- `POST /solution`: Solves a problem and returns the solution
- `POST /solver`: Returns all the problems of a specified solver
- `POST /problems`: Browse and remove problem submitions
- `POST /problem`: Submit a new problem

## Setup and Running

   ```bash
   docker-compose -f solveMyProblem.yml up solutions
   ```
