const jwt = require('jsonwebtoken');
const sequelize = require('../utils/database');
var initModels = require("../models/init-models");
var models = initModels(sequelize);
const path = require('path'); 
const fs = require('fs');
const { execSync } = require('child_process');
const axios = require('axios');
const calculateCost = require('../utils/calculateCost');


exports.postProblem = async (req, res, next) => {
    try {
        const { metadata, solverId, usersId } = req.body;

        // Decode user data from JWT
        const userData = jwt.decode(req.header('X-OBSERVATORY-AUTH'));

        // Log user data for debugging
        console.log('Decoded User Data:', userData);

        // Create a new problem in the database
        const newProblem = await models.Problems.create({
            status: "not solved",
            UsersId: usersId,
            dateCreated: new Date(),
            solverId: solverId,
            metadata: metadata
        });

        // Log the new problem for debugging
        console.log('New Problem Created:', newProblem);

        // Generate a new JWT token with problem details
        const token = jwt.sign({
            problem: {
                status: newProblem.status,
                UsersId: newProblem.UsersId,
                dateCreated: newProblem.dateCreated,
                solverId: newProblem.solverId,
                metadata: newProblem.metadata
            }
        }, process.env.JWT_SECRET, { expiresIn: '20s' });

        // Log the generated token for debugging
        console.log('Generated Token:', token);

        const allSubmissions = await models.Problems.findAll();
        console.log('All Submissions:', allSubmissions);

        // Prepare data for Axios request
        const url = `http://${process.env.BASE_URL}:4003/events`;

        const data = {
            type: 'PROBLEM SUBMIT',
            usersId: usersId
        }

        const headers = {
            'X-OBSERVATORY-AUTH': req.header('X-OBSERVATORY-AUTH'),
            "SERVICES-HEADER": process.env.SECRET_SERVICES
        };

        const config = { method: 'post', url: url, headers: headers, data: data };
        axios(config)
        .then(result => { 
            return res.status(200).json({ submissions: allSubmissions, token: token, message: 'Problem submitted successfully!', type: 'success' });
        })
        .catch(err => { 
            console.error(err);
            return res.status(500).json({ message: 'Internal server error.', type: 'error' });
        });
    } catch (err) {
        // Log the error for debugging
        console.error('Error:', err);
        if (err.response) {
            // Log the error response for debugging
            console.error('Error Response Data:', err.response.data);
        }
        return res.status(500).json({ message: 'Internal server error.', type: 'error' });
    }
};


exports.getProblems = async (req, res, next) => {
    let action = req.body.action;
    let submission_id = req.body.submission_id;

    try {
        if (!submission_id) {
            // Fetch all problems if no specific submission ID is provided
            const allSubmissions = await models.Problems.findAll();
            return res.status(200).json({submissions: allSubmissions, type: 'success', message: 'All Problems!' });
        } else {
            if (action === 'delete') {
                // Fetch the problem by its submission_id
                const problem = await models.Problems.findOne({ where: { id: submission_id } });
                
                if (!problem) {
                    return res.status(404).json({ message: 'Problem not found!', type: 'error' });
                }

                if (problem.status === 'solved') {
                    // Delete the related solution first if the problem is solved
                    await models.Solutions.destroy({ where: { ProblemsId: submission_id } });
                }

                // Delete the problem
                await models.Problems.destroy({ where: { id: submission_id } });

                // Fetch all remaining problems
                const allSubmissions = await models.Problems.findAll();
                return res.status(200).json({ submissions: allSubmissions, type: 'success', message: 'All Problems!' });
            } else {
                // Handle other actions if necessary
                return res.status(400).json({ message: 'Invalid action.', type: 'error' });
            }
        }
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Internal server error.', type: 'error' });
    }
};


exports.getSolverProblems = (req, res, next) => {
    let solverId = req.body.solverId;
    let validationError = false, errors = [];
    if (!solverId) {
        validationError = true;
        errors.push({ type: 'error', msg: 'Solver model is not defined.' });
    }
    
    if (validationError) {
        return res.status(400).json({ message: 'Validation Error!', errors: errors });
    }
    
    models.Problems.findAll({ where: { solverId: solverId } })
        .then(problems => {
            if (!problems) {
                return res.status(401).json({ message: 'Wrong solverId!', type: 'error' });
            }
            
            // Convert problems array to a plain object
            const problemsPlainObject = { problems: problems.map(problem => problem.toJSON()) };
            const token = jwt.sign(
                problemsPlainObject,
                process.env.JWT_SECRET,
                { expiresIn: '1h' }
            );

            res.status(200).json({ token: token, type: 'success', message: 'Solver Problems' });
        })
        .catch(err => {
            console.error(err);
            return res.status(500).json({ message: 'Internal server error.', type: 'error' });
        });
};

exports.postSolution = async (req, res, next) => {
    const problemId = req.body.submission_id;
    const inputFolderBase = path.join(__dirname, 'input');
    const userData = jwt.decode(req.header('X-OBSERVATORY-AUTH'));

    const results = [];

    try {
        const problem = await models.Problems.findOne({ where: { id: problemId } });
        console.log("Problem:", problem);

        if (!problem) {
            return res.status(401).json({ message: 'Wrong id!', type: 'error' });
        }

        if (problem.status === 'solved') {
            const solution = await models.Solutions.findOne({ where: { ProblemsId: problemId } });
            console.log("Solution:", solution);
            if (solution) {
                console.log("Solution submitted successfully");
                return res.status(200).json({ problem: problem, solution: solution, message: 'Solution submitted successfully!', type: 'success' });
            } else {
                return res.status(500).json({ message: 'Internal server error.', type: 'error' });
            }
        } else {
            const solverId = problem.solverId;

            // Calculate cost dynamically
            let costOfSolution;
            try {
                costOfSolution = calculateCost(solverId);
            } catch (e) {
                return res.status(500).json({ message: 'Error calculating the cost of the solution. Please try again.', type: 'error' });
            }

            const costUrl = `http://${process.env.BASE_URL}:4002/cost`;
            const costData = {
                credits: costOfSolution,
                id: userData.user.id
            };
            const headers = { "SERVICES-HEADER": process.env.SECRET_SERVICES };

            try {
                const costResult = await axios.post(costUrl, costData, { headers: headers });
                if (costResult.data.message !== 'READY' || costResult.data.type !== 'success') {
                    return res.status(400).json({ message: 'Unable to deduct credits. Please check your balance and try again.', type: 'error' });
                }
            } catch (err) {
                return res.status(500).json({ message: 'Error communicating with the credit service. Please try again later.', type: 'error' });
            }


            let metadata;
            // Check if metadata is already an object
            if (typeof problem.metadata === 'object') {
                metadata = problem.metadata;
            } else {
                // Attempt to parse it as JSON string
                try {
                    metadata = JSON.parse(problem.metadata);
                } catch (e) {
                    console.error('Invalid JSON in metadata:', problem.metadata);
                    return res.status(400).json({ message: 'Invalid metadata format', type: 'error' });
                }
            }

            const metadataArgs = Object.keys(metadata).map(key => `${metadata[key]}`).join(' ');
            let script;

            if (solverId == 6) {
                script = 'vrpSolver.py'; // Assign the correct script for VRP
                const inputFolder = path.join(inputFolderBase, `input_${solverId}`);


                fs.readdir(inputFolder, async (err, files) => {
                    if (err) {
                        return next(err);
                    }

                    for (const file of files) {
                        if (path.extname(file) === '.json') {
                            const filePath = path.join(inputFolder, file);
                            console.log(filePath);
                            const startTime = process.hrtime();

                            try {
                                const command = `python3 utils/${script} ${filePath} ${metadataArgs}`;
                                console.log(`Running command: ${command}`);
                                const output = execSync(command, { encoding: 'utf-8' });
                                console.log("Output:", output);

                                const endTime = process.hrtime(startTime);
                                const timeTaken = (endTime[0] * 1e9 + endTime[1]) / 1e9; // Time in seconds

                                results.push({
                                    file: file,
                                    timeTaken: timeTaken.toFixed(2) + 's',
                                    vehicleRoutes: JSON.parse(output)
                                });
                                console.log("Results:", results);

                            } catch (err) {
                                results.push({
                                    file: file,
                                    error: err.message
                                });
                            }
                        }
                    }

                    // Create a new solution in the database after processing files
                    const newSolution = await models.Solutions.create({
                        UsersId: userData.user.id,
                        ProblemsId: problemId,
                        dateCreated: new Date(),
                        data: results
                    });
                    console.log('Results:', results);

                    // Update the problem status to "solved"
                    problem.status = "solved";
                    await problem.save();

                    // Log the new solution for debugging
                    console.log('New Solution Created:', newSolution);

                    const url = `http://${process.env.BASE_URL}:4003/events`;

                    const data = {
                        type: 'SOLUTION SUBMIT',
                        usersId: userData.user.id
                    };

                    const headers = {
                        'X-OBSERVATORY-AUTH': req.header('X-OBSERVATORY-AUTH'),
                        "SERVICES-HEADER": process.env.SECRET_SERVICES
                    };

                    const config = { method: 'post', url: url, headers: headers, data: data };

                    axios(config)
                        .then(result => {
                            return res.status(200).json({ problem: problem, solution: newSolution, message: 'Solution submitted successfully!', type: 'success' });
                        })
                        .catch(err => {
                            console.error(err);
                            return res.status(500).json({ message: 'Internal server error.', type: 'error' });
                        });
                });
            
            }  else if (solverId == 0) {
                    script = 'multiknapsack.py'; // Assign the correct script for multiknapsack
                    const filePath = path.join(inputFolderBase, `input_${solverId}/${metadata.num_weights}_${metadata.num_bins}.json`);

                    const startTime = process.hrtime();
    
                    try {
                        const command = `python3 utils/${script} ${filePath}`;
                        console.log(`Running command: ${command}`);
                        const output = execSync(command, { encoding: 'utf-8' });
                        console.log("Output:", output);

                        const endTime = process.hrtime(startTime);
                        const timeTaken = (endTime[0] * 1e9 + endTime[1]) / 1e9; // Time in seconds

                        results.push({
                            timeTaken: timeTaken.toFixed(2) + 's',
                            output: JSON.parse(output)
                        });
                        console.log("Results:", results);

                    } catch (err) {
                        results.push({
                            error: err.message
                        });
                    }
    
                    // Create a new solution in the database after processing files
                    const newSolution = await models.Solutions.create({
                        UsersId: userData.user.id,
                        ProblemsId: problemId,
                        dateCreated: new Date(),
                        data: results
                    });
                    console.log('Results:', results);

                    // Update the problem status to "solved"
                    problem.status = "solved";
                    await problem.save();

                    // Log the new solution for debugging
                    console.log('New Solution Created:', newSolution);

                    const url = `http://${process.env.BASE_URL}:4003/events`;

                    const data = {
                        type: 'SOLUTION SUBMIT',
                        usersId: userData.user.id
                    };

                    const headers = {
                        'X-OBSERVATORY-AUTH': req.header('X-OBSERVATORY-AUTH'),
                        "SERVICES-HEADER": process.env.SECRET_SERVICES
                    };

                    const config = { method: 'post', url: url, headers: headers, data: data };

                    axios(config)
                        .then(result => {
                            return res.status(200).json({ problem: problem, solution: newSolution, message: 'Solution submitted successfully!', type: 'success' });
                        })
                        .catch(err => {
                            console.error(err);
                            return res.status(500).json({ message: 'Internal server error.', type: 'error' });
                        });
            } else {
                if (solverId == 1) {
                    script = 'cp_sat.py';
                } else if (solverId == 3) {
                    script = 'assignment.py';
                } else if (solverId == 4) {
                    script = 'scheduling.py';
                } else {
                    return res.status(400).json({ message: 'Unsupported solverId', type: 'error' });
                }

                try {
                    const startTime = process.hrtime(); // Moved startTime here for correct timing calculation

                    const command = `python3 utils/${script} ${metadataArgs}`;
                    console.log(`Running command: ${command}`);
                    const output = execSync(command, { encoding: 'utf-8' });
                    console.log("Output:", output);

                    const endTime = process.hrtime(startTime);
                    const timeTaken = (endTime[0] * 1e9 + endTime[1]) / 1e9; // Time in seconds

                    results.push({
                        timeTaken: timeTaken.toFixed(2) + 's',
                        output: JSON.parse(output)
                    });
                    console.log("Results:", results);

                } catch (err) {
                    results.push({
                        error: err.message
                    });
                }

                // Create a new solution in the database after processing
                const newSolution = await models.Solutions.create({
                    UsersId: userData.user.id,
                    ProblemsId: problemId,
                    dateCreated: new Date(),
                    data: results
                });
                console.log('Results:', results);

                // Update the problem status to "solved"
                problem.status = "solved";
                await problem.save();

                // Log the new solution for debugging
                console.log('New Solution Created:', newSolution);

                const url = `http://${process.env.BASE_URL}:4003/events`;

                const data = {
                    type: 'SOLUTION SUBMIT',
                    usersId: userData.user.id
                };

                const headers = {
                    'X-OBSERVATORY-AUTH': req.header('X-OBSERVATORY-AUTH'),
                    "SERVICES-HEADER": process.env.SECRET_SERVICES
                };

                const config = { method: 'post', url: url, headers: headers, data: data };

                axios(config)
                    .then(result => {
                        return res.status(200).json({ problem: problem, solution: newSolution, message: 'Solution submitted successfully!', type: 'success' });
                    })
                    .catch(err => {
                        console.error(err);
                        return res.status(500).json({ message: 'Internal server error.', type: 'error' });
                    });
            }

        }
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: 'Internal server error.', type: 'error' });
    }
};

exports.healthcheck = (req, res, next) => {
    sequelize.authenticate()
    .then(() => res.status(200).json({ service: 'Solutions', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - OK' }))
    .catch(err => res.status(200).json({ service: 'Solutions', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - FAILED' }))
}