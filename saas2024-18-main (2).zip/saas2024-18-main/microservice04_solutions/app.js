const express = require('express');
const cors = require('cors');
const originAuthentication = require('./middlewares/originAuthentication');

const solutions = require('./routes/solutions');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

app.use(originAuthentication);
app.use('/', solutions);

app.use((req, res, next) => { res.status(404).json({message: 'Not found!'}); })

module.exports = app;