const express = require('express');
const solutions = require('../controllers/solutions');
const auth = require('../middlewares/authentication')

const router = express.Router();

router.post('/problem', auth, solutions.postProblem);

router.post('/problems', auth, solutions.getProblems);

router.post('/solver', auth, solutions.getSolverProblems);

router.post('/solution', auth, solutions.postSolution);

router.get('/healthcheck', solutions.healthcheck);

module.exports = router;