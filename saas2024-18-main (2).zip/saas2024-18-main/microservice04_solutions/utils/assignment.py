"""Solve a multiple knapsack problem using a MIP solver."""
import argparse
import json
from ortools.linear_solver import pywraplp

def main(args):
    data = {}
    
    # Input the number of weights and bins from command line arguments
    num_weights = args.num_weights
    num_bins = args.num_bins
    
    # Input the weights
    weights = input(f"Enter the {num_weights} weights separated by spaces: ").split()
    data["weights"] = [int(weight) for weight in weights]
    
    # Input the bin capacities
    bin_capacities = input(f"Enter the {num_bins} bin capacities separated by spaces: ").split()
    data["bin_capacities"] = [int(capacity) for capacity in bin_capacities]
    
    data["num_items"] = num_weights
    data["all_items"] = range(data["num_items"])

    data["num_bins"] = num_bins
    data["all_bins"] = range(data["num_bins"])

    # Create the mip solver with the SCIP backend.
    solver = pywraplp.Solver.CreateSolver("SCIP")
    if solver is None:
        result = {
            "status": "error",
            "message": "SCIP solver unavailable."
        }
        print(json.dumps(result, indent=4))
        return

    # Variables.
    # x[i, b] = 1 if item i is packed in bin b.
    x = {}
    for i in data["all_items"]:
        for b in data["all_bins"]:
            x[i, b] = solver.BoolVar(f"x_{i}_{b}")

    # Constraints.
    # Each item is assigned to at most one bin.
    for i in data["all_items"]:
        solver.Add(sum(x[i, b] for b in data["all_bins"]) <= 1)

    # The amount packed in each bin cannot exceed its capacity.
    for b in data["all_bins"]:
        solver.Add(
            sum(x[i, b] * data["weights"][i] for i in data["all_items"])
            <= data["bin_capacities"][b]
        )

    # Objective.
    # Maximize total weight of packed items.
    objective = solver.Objective()
    for i in data["all_items"]:
        for b in data["all_bins"]:
            objective.SetCoefficient(x[i, b], data["weights"][i])
    objective.SetMaximization()

    # Solve the problem
    print(f"Solving with {solver.SolverVersion()}")
    status = solver.Solve()

    # Prepare the result dictionary
    result = {
        "status": "unknown",
        "total_packed_weight": 0,
        "bins": [],
        "message": ""
    }

    if status == pywraplp.Solver.OPTIMAL:
        result["status"] = "optimal"
        result["total_packed_weight"] = objective.Value()
        for b in data["all_bins"]:
            bin_details = {"bin": b, "items": [], "packed_weight": 0}
            for i in data["all_items"]:
                if x[i, b].solution_value() > 0:
                    item_detail = {
                        "item": i,
                        "weight": data["weights"][i]
                    }
                    bin_details["items"].append(item_detail)
                    bin_details["packed_weight"] += data["weights"][i]
            result["bins"].append(bin_details)
        result["message"] = "Solution found."
    else:
        result["status"] = "infeasible"
        result["message"] = "The problem does not have an optimal solution."

    # Print the JSON result
    print(json.dumps(result, indent=4))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Solve a multiple knapsack problem.")
    parser.add_argument("num_weights", type=int, help="The number of weights.")
    parser.add_argument("num_bins", type=int, help="The number of bins.")

    args = parser.parse_args()
    main(args)
