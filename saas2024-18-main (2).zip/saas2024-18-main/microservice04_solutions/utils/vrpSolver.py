import json
from math import radians, cos, sin, sqrt, atan2
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
import argparse

def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculates the Earth surface distance between two coordinates using the Haversine formula."""
    R = 6371000  # Radius of the Earth in meters
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c
    return distance

def load_distance_matrix(file_path):
    """Loads location data from a JSON file and calculates the distance matrix."""
    with open(file_path, 'r') as file:
        location_data = json.load(file)['Locations']
    distance_matrix = []
    for loc1 in location_data:
        row = []
        for loc2 in location_data:
            dist = calculate_distance(loc1['Latitude'], loc1['Longitude'], loc2['Latitude'], loc2['Longitude'])
            row.append(dist)
        distance_matrix.append(row)
    return distance_matrix

def create_data_model(num_vehicles, depot, max_distance, file_path):
    """Stores the data for the problem."""
    data = {}
    data['distance_matrix'] = load_distance_matrix(file_path)
    data['num_vehicles'] = num_vehicles
    data['depot'] = depot
    data['vehicle_capacities'] = [max_distance] * num_vehicles
    return data

def get_solution(data, manager, routing, solution):
    """Gets the solution as a JSON serializable object."""
    routes = []
    total_distance = 0

    for vehicle_id in range(data['num_vehicles']):
        index = routing.Start(vehicle_id)
        route = []
        route_distance = 0

        while not routing.IsEnd(index):
            node_index = manager.IndexToNode(index)
            route.append(node_index)
            previous_index = index
            index = solution.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(previous_index, index, vehicle_id)
        
        if route:
            # Add the depot (end point) to the route
            route.append(manager.IndexToNode(index))
            routes.append({
                'vehicle': vehicle_id,
                'route': route,
                'distance': route_distance
            })
        
        total_distance += route_distance
    
    return {
        'total_distance': total_distance,
        'routes': routes
    }

def main():
    parser = argparse.ArgumentParser(description='Solve a VRP problem.')
    parser.add_argument('file_path', type=str, help='Path to JSON file with location data')
    parser.add_argument('num_vehicles', type=int, help='Number of vehicles available')
    parser.add_argument('depot', type=int, help='Depot index position (e.g., 0)')
    parser.add_argument('max_distance', type=int, help='Maximum distance each vehicle can travel')

    args = parser.parse_args()

    # Load and prepare data model
    data = create_data_model(args.num_vehicles, args.depot, args.max_distance, args.file_path)

    # Create the routing index manager.
    manager = pywrapcp.RoutingIndexManager(len(data['distance_matrix']), data['num_vehicles'], data['depot'])

    # Create Routing Model.
    routing = pywrapcp.RoutingModel(manager)

    # Define cost of each arc.
    def distance_callback(from_index, to_index):
        """Returns the distance between the two nodes."""
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return data['distance_matrix'][from_node][to_node]

    transit_callback_index = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

    # Add Distance constraint.
    dimension_name = 'Distance'
    routing.AddDimension(
        transit_callback_index,
        0,  # no slack
        args.max_distance,  # vehicle maximum travel distance
        True,  # start cumul to zero
        dimension_name)
    distance_dimension = routing.GetDimensionOrDie(dimension_name)
    distance_dimension.SetGlobalSpanCostCoefficient(100)

    # Set first solution heuristic.
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)

    # Solve the problem.
    solution = routing.SolveWithParameters(search_parameters)

    # Check if a solution was found and print it
    if solution:
        # Get solution as JSON object
        solution_data = get_solution(data, manager, routing, solution)
        # Print the JSON object as a string
        print(json.dumps(solution_data))
    else:
        print(json.dumps({'error': 'No solution found. Please check the constraints and inputs.'}))

if __name__ == '__main__':
    main()
