import argparse
import json
from ortools.linear_solver import pywraplp

def main(args):
    # Load data from the JSON file
    with open(args.input_file, 'r') as file:
        data = json.load(file)

    # Create the mip solver with the SCIP backend.
    solver = pywraplp.Solver.CreateSolver("SCIP")
    if solver is None:
        result = {
            "status": "error",
            "message": "SCIP solver unavailable."
        }
        # Output the result as JSON
        print(json.dumps(result))
        return

    # Variables.
    # x[i, b] = 1 if item i is packed in bin b.
    x = {}
    for i in range(data["num_weights"]):
        for b in range(data["num_bins"]):
            x[i, b] = solver.BoolVar(f"x_{i}_{b}")

    # Constraints.
    # Each item is assigned to at most one bin.
    for i in range(data["num_weights"]):
        solver.Add(sum(x[i, b] for b in range(data["num_bins"])) <= 1)

    # The amount packed in each bin cannot exceed its capacity.
    for b in range(data["num_bins"]):
        solver.Add(
            sum(x[i, b] * data["weights"][i] for i in range(data["num_weights"]))
            <= data["bin_capacities"][b]
        )

    # Objective.
    # Maximize total weight of packed items.
    objective = solver.Objective()
    for i in range(data["num_weights"]):
        for b in range(data["num_bins"]):
            objective.SetCoefficient(x[i, b], data["weights"][i])
    objective.SetMaximization()

    # Solve the problem
    status = solver.Solve()

    # Prepare the result dictionary
    result = {
        "status": "unknown",
        "total_packed_weight": 0,
        "bins": [],
        "message": ""
    }

    if status == pywraplp.Solver.OPTIMAL:
        result["status"] = "optimal"
        result["total_packed_weight"] = objective.Value()
        for b in range(data["num_bins"]):
            bin_details = {"bin": b, "items": [], "packed_weight": 0}
            for i in range(data["num_weights"]):
                if x[i, b].solution_value() > 0:
                    item_detail = {
                        "item": i,
                        "weight": data["weights"][i]
                    }
                    bin_details["items"].append(item_detail)
                    bin_details["packed_weight"] += data["weights"][i]
            result["bins"].append(bin_details)
        result["message"] = "Solution found."
    else:
        result["status"] = "infeasible"
        result["message"] = "The problem does not have an optimal solution."

    # Print only the JSON result
    print(json.dumps(result))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Solve a multiple knapsack problem.")
    parser.add_argument("input_file", type=str, help="Path to the input JSON file.")

    args = parser.parse_args()
    main(args)