const DEFAULT = 10;
const LINEAR_OPTIMIZATION = 20
const CP_SAT = 30
const SCHEDULING = 40
const ROUTING = 50


function calculateCost(solverId) {
    let cost = DEFAULT;

    // Calculate number of credits needed to solve the problem
    if (solverId==0) {
        cost += LINEAR_OPTIMIZATION;
    }
    else if (solverId==1) {
        cost += CP_SAT;
    }
    else if (solverId==4) {
        cost += SCHEDULING;
    }
    else if (solverId==6) {
        cost += ROUTING;
    } 
    return cost;
}

module.exports = calculateCost;