import argparse
import json
from ortools.sat.python import cp_model

def main(employees: int, shifts: int, days: int) -> None:
    # Data.
    all_employees = range(employees)
    all_shifts = range(shifts)
    all_days = range(days)

    # Creates the model.
    model = cp_model.CpModel()

    # Creates shift variables.
    # shifts[(e, d, s)]: employee 'e' works shift 's' on day 'd'.
    schedule = {}
    for e in all_employees:
        for d in all_days:
            for s in all_shifts:
                schedule[(e, d, s)] = model.NewBoolVar(f"shift_e{e}_d{d}_s{s}")

    # Each shift is assigned to exactly one employee in the schedule period.
    for d in all_days:
        for s in all_shifts:
            model.AddExactlyOne(schedule[(e, d, s)] for e in all_employees)

    # Each employee works at most one shift per day.
    for e in all_employees:
        for d in all_days:
            model.AddAtMostOne(schedule[(e, d, s)] for s in all_shifts)

    # Try to distribute the shifts evenly.
    min_shifts_per_employee = (shifts * days) // employees
    max_shifts_per_employee = min_shifts_per_employee + (1 if (shifts * days) % employees != 0 else 0)

    for e in all_employees:
        shifts_worked = []
        for d in all_days:
            for s in all_shifts:
                shifts_worked.append(schedule[(e, d, s)])
        model.Add(min_shifts_per_employee <= sum(shifts_worked))
        model.Add(sum(shifts_worked) <= max_shifts_per_employee)

    # Creates the solver and solve.
    solver = cp_model.CpSolver()
    solver.parameters.linearization_level = 0
    solver.parameters.enumerate_all_solutions = True

    # JSON structure for results
    result = {
        "status": "unknown",
        "solutions": [],
        "statistics": {
            "conflicts": None,
            "branches": None,
            "wall_time_s": None,
            "solutions_found": None
        },
        "message": ""
    }

    class EmployeesPartialSolutionPrinter(cp_model.CpSolverSolutionCallback):
        """Print intermediate solutions."""

        def __init__(self, schedule, employees, days, shifts, limit):
            cp_model.CpSolverSolutionCallback.__init__(self)
            self._schedule = schedule
            self._employees = employees
            self._days = days
            self._shifts = shifts
            self._solution_count = 0
            self._solution_limit = limit
            self._solutions = []

        def on_solution_callback(self):
            self._solution_count += 1
            current_solution = {"day_schedules": []}
            for d in range(self._days):
                day_schedule = {"day": d, "assignments": []}
                for e in range(self._employees):
                    is_working = False
                    for s in range(self._shifts):
                        if self.Value(self._schedule[(e, d, s)]):
                            is_working = True
                            day_schedule["assignments"].append({
                                "employee": e,
                                "shift": s
                            })
                    if not is_working:
                        day_schedule["assignments"].append({
                            "employee": e,
                            "shift": None
                        })
                current_solution["day_schedules"].append(day_schedule)
            self._solutions.append(current_solution)

            if self._solution_count >= self._solution_limit:
                self.StopSearch()

        def get_solutions(self):
            return self._solutions

        def solution_count(self):
            return self._solution_count

    # Display the first five solutions.
    solution_limit = 5
    solution_printer = EmployeesPartialSolutionPrinter(
        schedule, employees, days, shifts, solution_limit
    )

    solver.Solve(model, solution_printer)

    # Populate JSON results
    if solution_printer.solution_count() > 0:
        result["status"] = "feasible"
        result["solutions"] = solution_printer.get_solutions()
        result["message"] = "Solutions found"
    else:
        result["status"] = "infeasible"
        result["message"] = "No solution found"

    # Update statistics
    result["statistics"] = {
        "conflicts": solver.NumConflicts(),
        "branches": solver.NumBranches(),
        "wall_time_s": solver.WallTime(),
        "solutions_found": solution_printer.solution_count()
    }

    # Print the JSON result
    print(json.dumps(result, indent=4))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Employee scheduling problem.")
    parser.add_argument("employees", type=int, help="Number of employees")
    parser.add_argument("shifts", type=int, help="Number of shifts")
    parser.add_argument("days", type=int, help="Number of days")
    args = parser.parse_args()

    main(args.employees, args.shifts, args.days)