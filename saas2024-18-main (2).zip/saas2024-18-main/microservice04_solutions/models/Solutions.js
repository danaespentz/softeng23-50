module.exports = function(sequelize, DataTypes) {
  return sequelize.define('Solutions', {
    id: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    data: {
      type: DataTypes.ARRAY(DataTypes.JSONB),
      allowNull: false
    },
    dateCreated: {
      type: DataTypes.DATE,
      allowNull: false
    },
    UsersId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    ProblemsId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Problems',
        key: 'id'
      }
    }
  }, {
    sequelize,
    tableName: 'Solutions',
    schema: process.env.DB_SCHEMA,
    timestamps: false,
    indexes: [
      {
        name: "Solutions_pkey",
        unique: true,
        fields: [
          { name: "id" },
        ]
      },
    ]
  });
};
