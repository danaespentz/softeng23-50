var DataTypes = require("sequelize").DataTypes;
var _Problems = require("./Problems");
var _Solutions = require("./Solutions");
var _Events = require("./Events");

function initModels(sequelize) {
  var Problems = _Problems(sequelize, DataTypes);
  var Solutions = _Solutions(sequelize, DataTypes);
  var Events = _Events(sequelize, DataTypes);

  // relationships between Tables
  Solutions.belongsTo(Problems, { foreignKey: "ProblemsId"});
  Problems.hasMany(Solutions, { foreignKey: "ProblemsId"});

  return {
    Solutions,
    Problems,
    Events
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;