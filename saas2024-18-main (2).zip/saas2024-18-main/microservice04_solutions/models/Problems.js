module.exports = function(sequelize, DataTypes) {
    return sequelize.define('Problems', {
        id: {
            autoIncrement: true,
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true
        },
        metadata: {
            type: DataTypes.JSON,
            allowNull: false
        },
        status: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        dateCreated: {
            type: DataTypes.DATE,
            allowNull: false
        },
        UsersId: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        solverId: {
            type: DataTypes.INTEGER,
            allowNull: false,
        }
    }, {
        sequelize,
        tableName: 'Problems',
        schema: process.env.DB_SCHEMA,
        timestamps: false,
        indexes: [{
            name: "Problems_pkey",
            unique: true,
            fields: [
                { name: "id" },
            ]
        }, ]
    });
};
