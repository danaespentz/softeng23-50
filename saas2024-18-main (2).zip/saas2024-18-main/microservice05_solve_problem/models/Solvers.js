module.exports = function(sequelize, DataTypes) {
    return sequelize.define('Solvers', {
        id: {
            autoIncrement: true,
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true
        },
        name: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        metadata: {
            type: DataTypes.JSON,
            allowNull: false
        },
        input: {
            type: DataTypes.JSON,
            allowNull: false
        }
    }, {
        sequelize,
        tableName: 'Solvers',
        schema: process.env.DB_SCHEMA,
        timestamps: false,
        indexes: [{
            name: "Solvers_pkey",
            unique: true,
            fields: [
                { name: "id" },
            ]
        }]
    });
};
