var DataTypes = require("sequelize").DataTypes;
var _SolverModels = require("./Solvers");

function initModels(sequelize) {
  var Solvers = _SolverModels(sequelize, DataTypes);

  return {
    Solvers,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
