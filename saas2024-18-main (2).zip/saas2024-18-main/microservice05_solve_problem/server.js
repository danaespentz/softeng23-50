const app = require("./app");
const sequelize = require("./utils/database");
const initModels = require("./models/init-models");
require('custom-env').env('localhost');

const port = Number(4005);

const models = initModels(sequelize);
const { Solvers } = models;

// Function to initialize solvers in the database
async function initializeSolvers() {
    const solvers = [
        { id: 0, name: 'Linear optimization', metadata: ['num_weights', 'num_bins'], input: ['4_3.json', '5_1.json', '5_3.json', '6_3.json'] },
        { id: 1, name: 'CP-SAT', metadata: ['board_size'], input: [] },
        { id: 2, name: 'Integer optimization', metadata: {}, input: [] },
        { id: 3, name: 'Assignment', metadata: ['number_of_workers', 'number_of_tasks'], input: [] },
        { id: 4, name: 'Scheduling', metadata: ['employees','shifts','days'], input: [] },
        { id: 5, name: 'Packing', metadata: {}, input: [] },
        { id: 6, name: 'Vehicle Routing', metadata: ['deposit', 'num_vehicles', 'max_distance'], input: ['locations_20.json', 'locations_200.json', 'locations_1000.json'] },
        { id: 7, name: 'Network flows', metadata: {}, input: [] },
    ];

    for (const solver of solvers) {
        await Solvers.create(solver);
    }
}

sequelize
    .query(`CREATE SCHEMA IF NOT EXISTS "${process.env.DB_SCHEMA}";`)
    .then(() => {
        initModels(sequelize);
        sequelize
            .sync({ force: true }) // Note: force: true will drop and recreate the database on every startup
            .then(async () => {
                await initializeSolvers(); // Initialize solvers after database sync
                app.listen(port, () => {
                    console.log(`Solve Problem Service running on port ${port}!`);
                });
            })
            .catch((err) => console.log(err));
    })
    .catch((err) => console.log(err));
