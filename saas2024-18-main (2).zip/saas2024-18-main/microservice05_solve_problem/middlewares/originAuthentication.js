module.exports = (req, res, next) => {
    const servicesHeader = req.header('services-header');

   if (servicesHeader !== undefined) 
       servicesHeader === process.env.SECRET_SERVICES 
       ? next() : res.status(403).json({ message: 'Not allowed origin.', type: 'error' });
   
   else return res.status(403).json({ message: 'Not allowed origin.', type: 'error' });
};