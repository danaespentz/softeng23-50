const sequelize = require('../utils/database');
var initModels = require("../models/init-models");
var models = initModels(sequelize);

module.exports = async (req, res, next) => {
    try {
        let solverId = req.body.solverId;
        console.log("Solver Id", solverId);

        let validationError = false;
        let errors = [];
        if (!solverId) {
            validationError = true;
            errors.push({ type: 'error', msg: 'Problem Solver is not defined.' });
        }
        if (validationError) {
            return res.status(400).json({ message: 'Validation Error!', errors: errors });
        }

        const solver = await models.Solvers.findOne({ where: { id: solverId } });

        if (!solver) {
            return res.status(401).json({ message: 'Wrong id!', type: 'error' });
        }
        console.log('Solver:', solver);

        return res.status(200).json({ solver: solver, message: 'Solver found successfully!', type: 'success' });
    } catch (error) {
        console.error('Error:', error);
        return res.status(500).json({ message: 'Internal Server Error!', type: 'error' });
    }
};
