const sequelize = require('../utils/database');
var initModels = require("../models/init-models");
var models = initModels(sequelize);

module.exports = async (req, res, next) => {
    sequelize.authenticate()
    .then(() => res.status(200).json({ service: 'Solutions', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - OK' }))
    .catch(err => res.status(200).json({ service: 'Solutions', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - FAILED' }))
}