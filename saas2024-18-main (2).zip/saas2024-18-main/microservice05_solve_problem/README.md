# Solve Problem Service

## Overview
The Solve Problem Service is responsible for finding the appropriate problem solver and return its metadata.

## API Endpoints
- `GET /healthcheck`: Check the health of the service.
- `GET /solver`: Finds solver and returns its metadata

## Setup and Running

   ```bash
   docker-compose -f solveMyProblem.yml up solve_problems
   ```
