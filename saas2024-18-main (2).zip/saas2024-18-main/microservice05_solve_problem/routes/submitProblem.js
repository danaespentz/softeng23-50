const express = require('express');

const getSolver = require('../controllers/getSolver');
const healthcheck = require('../controllers/healthcheck');
const auth = require('../middlewares/authentication');

const router = express.Router();

router.get('/solver', auth, getSolver);

router.get('/healthcheck', auth, healthcheck);


module.exports = router;