const express = require('express');

const signIn = require('../controllers/signIn');
const credits = require('../controllers/credits');
const cost = require('../controllers/cost');
const signUp = require('../controllers/signUp');
const status = require('../controllers/status');
const router = express.Router();

router.post('/signin', signIn);

router.post('/credits', credits);

router.post('/cost', cost);

router.post('/signup', signUp);

router.get('/status', status);

module.exports = router;