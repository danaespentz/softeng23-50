const jwt = require('jsonwebtoken');
const sequelize = require('../utils/database');
var initModels = require("../models/init-models");
var models = initModels(sequelize);

module.exports = (req, res, next) => {
    const email = req.body.email;
    const password = req.body.password;

    if (!email || !password) return res.status(400).json({ message: 'Some parameters are missing', type: 'error' });

    models.Users.findOne({ where: { email: email } })
    .then(user => {
        if (!user) return res.status(401).json({ message:'Wrong credentials!', type: 'error' });
        
        // Password comparison should ideally be done with a secure method like bcrypt
        if (password === user.password) {
            const token = jwt.sign(
                {
                    user: {
                        id: user.id,
                        name: user.name,
                        dateCreated: user.dateCreated,
                        username: user.email,
                        credits: user.credits,
                    }
                },
                process.env.JWT_SECRET,
                { expiresIn: '1h'}
            );
            res.status(200).json({ token: token, type: 'success', message:'Welcome back!' });
        }
        else {
            // Password mismatch
            return res.status(401).json({ message:'Wrong credentials!', type: 'error' });
        }
    })
    .catch(err => {
        console.error(err);
        return res.status(500).json({ message: 'Internal server error.', type: 'error' });
    });
}
