const sequelize = require('../utils/database');

module.exports = (req, res, next) => {

    sequelize.authenticate()
    .then(() => res.status(200).json({ service: 'Accounts', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - OK' }))
    .catch(err => res.status(200).json({ service: 'Accounts', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - FAILED' }))

}