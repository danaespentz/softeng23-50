const sequelize = require('../utils/database');
const initModels = require("../models/init-models");
const models = initModels(sequelize);

module.exports = (req, res, next) => {
    const new_credits = parseInt(req.body.new_credits);
    const id = req.body.id;

    console.log(new_credits);

    if (!new_credits) return res.status(400).json({ message: 'Your balance is the same', type: 'error' });

    models.Users.findOne({ where: { id: id } })
    .then(user => {
        if (user) {
            // Update user's credits by adding new_credits
            const updatedCredits = parseInt(user.credits) + new_credits;
            // Update user's credits in the database
            return user.update({ credits: updatedCredits });
        } else {
            return Promise.reject("User not found");
        }
    })
    .then(updatedUser => {
        // Return the updated balance
        res.status(200).json({ balance: updatedUser.credits, type: 'success', message:'New Credits!' });
    })
    .catch(err => {
        console.error(err);
        if (err === "User not found") {
            return res.status(404).json({ message: 'User not found.', type: 'error' });
        } else {
            return res.status(500).json({ message: 'Internal server error.', type: 'error' });
        }
    });
};
