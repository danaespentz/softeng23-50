const jwt = require('jsonwebtoken');
const axios = require('axios');

const sequelize = require('../utils/database');
var initModels = require("../models/init-models");
var models = initModels(sequelize);

module.exports = (req, res, next) => {

    const name = req.body.name;
    const password = req.body.password;
    const email = req.body.email;
    
    if (!name || !email || !password) return res.status(400).json({message: 'Some fields are missing!', type: 'error'});

    models.Users.findOne({ where: { email: email } })
    .then(user => {
        if (!user) {
            newUser = models.Users.create({
                    name: name,
                    email: email,
                    dateCreated: Date.now(),
                    password: password,
                    credits: 100
                })
            const token = jwt.sign({
                user: {
                    id: newUser.id,
                    name: newUser.name,
                    dateCreated: newUser.dateCreated,
                    username: newUser.email,
                    credits: newUser.credits
                }}, process.env.JWT_SECRET, { expiresIn: '20s' }
            );

            const url = `http://${process.env.BASE_URL}:4003/events`;

            const headers = { 
                "SERVICES-HEADER": process.env.SECRET_SERVICES,
                'X-OBSERVATORY-AUTH': token
            };
                
            const config = { method: 'post', url: url, headers: headers, data: { type: 'USER CREATE', usersId: newUser.id } };
                
            axios(config)
                .then(result => { res.status(200).json({ signup: 'true', message: 'Account created succesfully!', type: 'success' })})
                .catch(err => { return res.status(500).json({ message: 'Internal server error.', type: 'error' }) })
                
        }
        else {
            return res.status(200).json({message: 'There is a already a user with these credentials.', type: 'error'})
        }
    })
    .catch(err => {
        return res.status(500).json({message: 'Internal server error.', type: 'error'})
    });

}