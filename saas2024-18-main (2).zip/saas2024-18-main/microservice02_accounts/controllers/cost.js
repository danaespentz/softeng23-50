const sequelize = require('../utils/database');
const initModels = require("../models/init-models");
const models = initModels(sequelize);

module.exports = (req, res, next) => {
    const cost = parseInt(req.body.credits);
    const id = req.body.id;

    if (!cost || isNaN(cost)) {
        return res.status(400).json({ message: 'Invalid cost provided. Please check the input and try again.', type: 'error' });
    }

    models.Users.findOne({ where: { id: id } })
        .then(user => {
            if (!user) {
                return res.status(404).json({ message: 'User not found. Please check the user ID and try again.', type: 'error' });
            }

            if (user.credits < cost) {
                return res.status(400).json({ message: `Insufficient credits. You need ${cost} credits but have only ${user.credits}. Please purchase more credits and try again.`, type: 'error' });
            }

            const updatedCredits = user.credits - cost;
            return user.update({ credits: updatedCredits });
        })
        .then(updatedUser => {
            return res.status(200).json({ type: 'success', message: 'READY' });
        })
        .catch(err => {
            console.error(err);
            return res.status(500).json({ message: 'Unexpected error occurred. Please try again later.', type: 'error' });
        });
};

