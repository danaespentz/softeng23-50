# Accounts Service

## Overview
The Accounts Service is responsible for managing user accounts. 

## Features
User sign up
User login
Retrieval of user information

## API Endpoints
- `GET /status`: Check the health of the service.
- `POST /signup`: Sign up a new user.
- `POST /signin`: Log in an existing user.
- `POST /credits`: Manages user credits.
- `POST /cost`: Reduces user credits to solve problems.

## Setup and Running

   ```bash
   docker-compose -f solveMyProblem.yml up accounts
   ```
