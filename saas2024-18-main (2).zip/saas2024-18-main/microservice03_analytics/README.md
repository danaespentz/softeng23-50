# Analytics Service

## Overview
The Analytics Service is responsible for calculating user analytics.

## Features
Problems Submitted
Problems Solved
Contributions per Day

## API Endpoints
- `GET /status`: Check the health of the service.
- `POST /events`: Manages user submition logs
- `POST /analytics`: Calculates the user statistics

## Setup and Running

   ```bash
   docker-compose -f solveMyProblem.yml up analytics
   ```
