const express = require('express');

const analytics = require('../controllers/analytics');
const auth = require('../middlewares/authentication')

const router = express.Router();

router.get('/analytics', auth, analytics.stats);

router.post('/events', auth, analytics.events);

router.get('/status', analytics.status);

module.exports = router;