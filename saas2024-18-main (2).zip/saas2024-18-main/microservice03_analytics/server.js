
const app = require("./app");
const chalk = require("chalk");
const sequelize = require('./utils/database');
var initModels = require("./models/init-models");

const port = Number(4003);

sequelize
.query(`CREATE SCHEMA IF NOT EXISTS "${process.env.DB_SCHEMA}";`)
.then(() => {
    initModels(sequelize);
    sequelize
        .sync({
            force: true,
        })
        .then((result) => {
            app.listen(port, () => {
                console.log(chalk.green(`Analytics Service running on port ${port}!`));
            });
        })
        .catch((err) => console.log(err));
})
.catch((err) => console.log(err));

    