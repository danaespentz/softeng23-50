const jwt_decode = require('jwt-decode');
const sequelize = require('../utils/database');
var initModels = require("../models/init-models");
var models = initModels(sequelize);
const calcDays = require('../utils/calcDays');

exports.stats = (req, res, next) => {

    let totalProblems, totalSolutions, solved_per_day, daysRegistered;

    /* retrieve user data from AUTH Header */
    const userData = jwt_decode(req.header('X-OBSERVATORY-AUTH'));

    /* retrieve all problems and solutions that user with id userData.user.id submitted */
    let analyticsPromise = new Promise((resolve, reject) => {
        models.Users.findAll({ raw: true, where: { id: userData.user.id } })
        .then(row => {
            totalProblems = row[0].problems;
            totalSolutions = row[0].solutions;
            resolve();
        })
        .catch(err => { return res.status(500).json({ message: 'Internal server error', type: 'error' }); })
    })

    /* after retrieving all data from analyticsPromise calculate days registered and contributions */
    Promise.all([analyticsPromise]).then(() => {
        
        daysRegistered = calcDays(Date.now(), new Date(userData.user.dateCreated));
        
        solved_per_day = totalSolutions / daysRegistered;

        return res.status(200).json({
            totalProblems: totalProblems,
            totalSolutions: totalSolutions,
            daysRegistered: daysRegistered,
            solved_per_day: solved_per_day.toFixed(2),
        })

    })
    .catch(err => { return res.status(500).json({ message: 'Internal server error', type: 'error' }); })

}

exports.events = (req, res, next) => {
    const type = req.body.type;
    console.log('Event Type:', type);

    if (type === 'PROBLEM SUBMIT') {
        models.Users.increment('problems', { by: 1, where: { id: req.body.usersId } })
            .then(() => res.status(200).json({}))
            .catch((error) => {
                console.error('Error incrementing problems:', error);
                res.status(500).json({ message: 'Internal server error', type: 'error' });
            });

    } else if (type === 'SOLUTION SUBMIT') {
        models.Users.increment('solutions', { by: 1, where: { id: req.body.usersId } })
            .then(() => res.status(200).json({}))
            .catch((error) => {
                console.error('Error incrementing solutions:', error);
                res.status(500).json({ message: 'Internal server error', type: 'error' });
            });

    } else if (type === 'USER CREATE') {
        console.log(models.Users);
        models.Users.create({ id: req.body.usersId, problems: 0, solutions: 0 })
            .then(() => res.status(200).json({}))
            .catch((error) => {
                console.error('Error creating user:', error);
                res.status(500).json({ message: 'Internal server error', type: 'error' });
            });

    } else {
        res.status(200).json({});
    }
};

/** returns the status of this specific service with sequelize.authenticate.
 * If successful then connection to database is OK else its not OK
 */
exports.status = (req, res, next) => {

    sequelize.authenticate()
    .then(() => res.status(200).json({ service: 'Analytics', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - OK' }))
    .catch(err => res.status(200).json({ service: 'Analytics', status: 'UP', uptime: Math.floor(process.uptime()), database: 'Connection - FAILED' }))

}